package inventorymanagement;
import java.util.*;
import javax.swing.*;
import java.sql.*;
public class MinMax {
	JLabel lb1;
	JFrame f;
	JButton btn1,btn2,btn3;
	JList list1;
	static int f1[][];
	static ArrayList<Integer> list=new ArrayList<Integer>();
	
	static TreeMap<Integer, Integer> map=new TreeMap<Integer, Integer>();
	static int []item,frequency,item1,item2,item3,frq;
	static int top=10,f_count=0;
	static String productName[],prd[],prd2[];
	static String tdata[][];
	public MinMax() {
		
	}
	public static Connection connectionProvider() throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");   
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/management","root","root");
		return con;
	}
	public static void minSaleCounter() throws Exception
	{
		Connection con=MinMax.connectionProvider();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select product_id,count(product_id) as p_id from sales_fact_1997 group by product_id order by product_id");
		while(rs.next())
		{
			int key=rs.getInt("p_id");
			int value=rs.getInt(1);
			map.put(key,value);
			
		}
		int count=0;
		int k=0;
		item=new int[10];
		item1=new int[10];
		frequency=new int[10];
		Set<?> set=map.entrySet();
		Iterator<?> itr=set.iterator();
		while(itr.hasNext())
		{
			Map.Entry<?, ?> m=(Map.Entry<?, ?>)itr.next();
			if(count<10)
			{
				
				item[k]=(Integer)m.getValue();
				item1[k]=(Integer)m.getValue();
				frequency[k]=(Integer)m.getKey();
				k++;
			}
			count++;
		}
	}
	public static void maxSaleCounter() throws Exception
	{
		Connection con=MinMax.connectionProvider();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select product_id,count(product_id) as p_id from sales_fact_1997 group by product_id order by product_id desc");
		while(rs.next())
		{
			int key=rs.getInt("p_id");
			int value=rs.getInt(1);
			map.put(key,value);
			
		}
		int size=map.size()-10;
		int count=0;
		int k=10;
		item=new int[10];
		item1=new int[10];
		frequency=new int[10];
		Set<?> set=map.entrySet();
		Iterator<?> itr=set.iterator();
		while(itr.hasNext())
		{
			Map.Entry<?, ?> m=(Map.Entry<?, ?>)itr.next();
			if(size<=count)
			{
				k--;
				item[k]=(Integer)m.getValue();
				item1[k]=(Integer)m.getValue();
				frequency[k]=(Integer)m.getKey();
			}
			count++;
		}
	}
	
	//---------------------------------------------------------------btn1---------
	public static void maximumSoldProduct()
	{
		try {
			MinMax.maxSaleCounter();
			Connection con=connectionProvider();
			Statement stmt=con.createStatement();
			String s[]=new String[10];
			productName=new String[10];
			tdata=new String[10][3];
			for(int i=0; i<10; i++)
			{
				ResultSet rset=stmt.executeQuery("Select *from product where product_id="+item[i]);
				if(rset.next())
				{
					productName[i]=rset.getString(4);
					//System.out.println(rset.getString(3)+" : "+frequency[i]);
					s[i]=productName[i]+" : "+frequency[i];
					tdata[i][0]=rset.getString(4);
					tdata[i][1]=String.valueOf(frequency[i]);
				}
			}
		
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	
	
	//--------------------------------------------------end btn1------------------
	
	//--------------------------------------------------start btn2------------------
	public static void maxTogether()
	{
		try
		{
		
			for(int i=0; i<item.length; i++)
			{
				for(int j=i; j<item1.length; j++)
				{
					if(item[i]!=item1[j])
					{
						f_count++;
					}
				}
			}
		Connection con=MinMax.connectionProvider();
		Statement stmt=con.createStatement();
		f1=new int[10][10];
		ResultSet rs=stmt.executeQuery("select distinct customer_id as c_id  from sales_fact_1997");
		TreeSet<Integer> set1=new TreeSet<Integer>();
		while(rs.next())
		{
			set1.add(rs.getInt("c_id"));
		}
		Iterator<Integer> itr=set1.iterator();
		while(itr.hasNext())
		{
			int x=itr.next();
					rs=stmt.executeQuery("select *from sales_fact_1997 where customer_id="+x);
					while(rs.next())
					{
						list.add(rs.getInt(1));
					}
						for(int i=0; i<item.length; i++)
						{
							for(int j=i; j<item1.length; j++)
							{			
								if(item[i]!=item1[j])
								{
									
									if(list.contains(item[i]))
									{
										if(list.contains(item1[j]))
										{
											f1[i][j]+=1;
												
										}
									}
									
								}
							}
						}
					list.clear();			
		}
		prd=new String[f_count];
		prd2=new String[f_count];
		frq=new int[f_count];
		int l=0,c=0;
		String k1="",k2="";
		for(int i=0; i<item.length; i++)
		{
			for(int j=i; j<item1.length; j++)
			{
				if(item[i]!=item1[j])
				{			
					rs=stmt.executeQuery("select *from product where product_id="+item[i]);
					if(rs.next())
					{
						k1=rs.getString(4);
					}
					rs=stmt.executeQuery("select *from product where product_id="+item1[j]);
					if(rs.next())
					{
						k2=rs.getString(4);
					}
					
					int value=f1[i][j];
					prd[l]=k1;
					prd2[l]=k2;
					frq[l]=value;
					l++;c++;
				}
			}
		}
		for(int i=0; i<frq.length; i++)
		{
			for(int j=i+1; j<frq.length-1-i; j++)
			{
				if(frq[j]>frq[i])
				{
					int temp=frq[j];
					frq[j]=frq[i];
					frq[i]=temp;
					String temp1=prd[j];
					prd[j]=prd[i];
					prd[i]=temp1;
					temp1=prd2[j];
					prd2[j]=prd2[i];
					prd2[i]=temp1;
				}
			}
		}
		for(int i=0; i<frq.length; i++)
		{
			if(i<10)
			{
				
				tdata[i][0]=prd[i];
				tdata[i][1]=prd2[i];
				tdata[i][2]=String.valueOf(frq[i]);
			
			}
			else
			{
				break;
			}
		}
		
		}catch(Exception ex){}
	
}
	
//--------------------------------------btn3----------------
	public static void minimumSoldProduct()
	{
		try {
			MinMax.minSaleCounter();
			Connection con=connectionProvider();
			Statement stmt=con.createStatement();
			String s[]=new String[10];
			productName=new String[10];
			tdata=new String[10][3];
			for(int i=0; i<10; i++)
			{
				ResultSet rset=stmt.executeQuery("Select *from product where product_id="+item[i]);
				if(rset.next())
				{
					
					tdata[i][0]=rset.getString(4);
					tdata[i][1]=String.valueOf(frequency[i]);
				}
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}
