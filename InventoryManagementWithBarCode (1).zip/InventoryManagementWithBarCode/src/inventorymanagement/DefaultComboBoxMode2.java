package inventorymanagement;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aditya
 */
class DefaultComboBoxMode2 {

    void addElement(String company) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

}
