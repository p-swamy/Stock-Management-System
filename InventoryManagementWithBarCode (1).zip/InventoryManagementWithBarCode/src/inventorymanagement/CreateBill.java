package inventorymanagement;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Registration.java
 *
 * Created on Dec 4, 2010, 2:13:37 PM
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
import java.util.*;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import java.text.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import connection.connect;

public class CreateBill extends javax.swing.JFrame {
    private String Onclick;

    private static class txt_date {

        public txt_date() {
         
                
        }
    }
 Connection con1 = null;
    ResultSet rst1= null;
    PreparedStatement pst1 = null;
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement ps = null;
    Statement st = null;
    String cus_no = null;
    String name = null;
    Object gender = null;
    Object dd, mm, yy = null;
    String dob = null;
    String cont_no = null;
    String email = null;
    String address = null;
  Timer t1;
  float total=0;
  float discount=0;
  float price=0;
    java.util.Date d;
    /** Creates new form Registration */
    public CreateBill() {
        initComponents();
        txtCode.grabFocus();
        
        DefaultComboBoxModel m2=(DefaultComboBoxModel)txtname.getModel();


        try {

            Class.forName("java.sql.Driver");
            Connection con= connection.connect.makeConnection();
            Statement stmt=con.createStatement();
            String q="Select * from Items ;";
            ResultSet rs=stmt.executeQuery(q);
            while(rs.next())
            {
              String company=rs.getString("Item_Id");
              m2.addElement(company);
             }
            rs.close();
            stmt.close();
            con.close();
         }

        catch(Exception e) {
            JOptionPane.showMessageDialog(null,"error");
        }
        
        

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtenrol_no = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cmbdd = new javax.swing.JComboBox();
        cmbmm = new javax.swing.JComboBox();
        cmbyy = new javax.swing.JComboBox();
        jPanel3 = new javax.swing.JPanel();
        btnsearch = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        btnclear = new javax.swing.JButton();
        btndelete = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        txtcontactno = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtprice = new javax.swing.JTextField();
        jTextField1 = new javax.swing.JTextField();
        txtqty = new javax.swing.JLabel();
        txtqtyy = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txttotal = new javax.swing.JTextField();
        txtname = new javax.swing.JComboBox();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        txtqty1 = new javax.swing.JLabel();
        txtDiscount = new javax.swing.JTextField();
        btnsave1 = new javax.swing.JButton();
        txtDiscount1 = new javax.swing.JTextField();
        txtqty3 = new javax.swing.JLabel();
        txtCode = new javax.swing.JTextField();
        btnsave2 = new javax.swing.JButton();
        btnsave = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registraion Form");

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 13));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                .addGap(804, 804, 804))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 16));
        jLabel3.setText("Bill Form");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel4.setText("Sales Id");

        txtenrol_no.setEditable(false);
        txtenrol_no.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtenrol_noMouseClicked(evt);
            }
        });
        txtenrol_no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtenrol_noActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel5.setText("Product Id");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel6.setText("Product Name");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel7.setText("Date");

        cmbdd.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DD", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        cmbmm.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MM", "Jan", "Feb", "Mar", "Apr", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }));

        cmbyy.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "YYYY", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020" }));
        cmbyy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbyyActionPerformed(evt);
            }
        });

        btnsearch.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        btnupdate.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btnupdate.setText("Update");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });

        btnclear.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btnclear.setText("Clear");
        btnclear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnclearActionPerformed(evt);
            }
        });

        btndelete.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btndelete.setText("Delete");
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addComponent(btnupdate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnsearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btndelete)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnclear)
                .addContainerGap(122, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnupdate)
                    .addComponent(btnsearch)
                    .addComponent(btndelete)
                    .addComponent(btnclear))
                .addContainerGap())
        );

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel8.setText("Customer Name");

        txtcontactno.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtcontactnoMouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel9.setText("Product Price");

        txtqty.setFont(new java.awt.Font("Tahoma", 1, 11));
        txtqty.setText("Quantity");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11));
        jLabel10.setText("Total");

        txttotal.setEditable(false);
        txttotal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txttotalMouseClicked(evt);
            }
        });
        txttotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttotalActionPerformed(evt);
            }
        });

        txtname.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--Select--" }));
        txtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 12));
        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12));
        jButton2.setText("New Customer");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        txtqty1.setFont(new java.awt.Font("Tahoma", 1, 11));
        txtqty1.setText("Discount");

        btnsave1.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btnsave1.setText("Get Total");
        btnsave1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsave1ActionPerformed(evt);
            }
        });

        txtqty3.setFont(new java.awt.Font("Tahoma", 1, 11));
        txtqty3.setText("Enter Bar Code");

        txtCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodeActionPerformed(evt);
            }
        });

        btnsave2.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btnsave2.setText("Get");
        btnsave2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsave2ActionPerformed(evt);
            }
        });

        btnsave.setFont(new java.awt.Font("Times New Roman", 1, 12));
        btnsave.setText("Save");
        btnsave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsaveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(350, 350, 350)
                        .addComponent(jLabel3))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel8)
                                    .addComponent(txtqty)
                                    .addComponent(txtqty1)
                                    .addComponent(txtqty3))
                                .addGap(88, 88, 88)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(txtCode, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnsave2))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtqtyy)
                                            .addComponent(jTextField1)
                                            .addComponent(txtcontactno)
                                            .addComponent(txtenrol_no, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE))
                                        .addGap(57, 57, 57)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel7)
                                            .addComponent(jLabel9)
                                            .addComponent(jLabel10))
                                        .addGap(63, 63, 63)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(txttotal)
                                                .addGroup(jPanel2Layout.createSequentialGroup()
                                                    .addComponent(cmbdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addComponent(cmbmm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(14, 14, 14)
                                                    .addComponent(cmbyy, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addComponent(txtprice))))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(txtDiscount, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btnsave1))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButton1)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2)
                                .addGap(193, 193, 193)))))
                .addContainerGap(83, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(128, Short.MAX_VALUE)
                .addComponent(btnsave)
                .addGap(38, 38, 38)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(133, 133, 133))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(0, 417, Short.MAX_VALUE)
                    .addComponent(txtDiscount1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 418, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(txtenrol_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(cmbdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cmbyy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cmbmm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtcontactno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9)
                        .addComponent(txtprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(42, 42, 42)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtqty)
                    .addComponent(txtqtyy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txttotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDiscount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtqty1)
                    .addComponent(btnsave1))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtqty3)
                    .addComponent(txtCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsave2))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(btnsave)))
                .addContainerGap(141, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(0, 303, Short.MAX_VALUE)
                    .addComponent(txtDiscount1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 304, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        Sales_Person rg = new Sales_Person();
        dispose();
        rg.show();
}//GEN-LAST:event_jLabel1MouseClicked
    
    private void btnsaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsaveActionPerformed

        // TODO add your handling code here:
        String salesid = txtenrol_no.getText();
        String productid = (String) txtname.getSelectedItem();
        String pname = jTextField1.getText();
        dd = cmbdd.getSelectedItem();
        mm = cmbmm.getSelectedItem();
        yy = cmbyy.getSelectedItem();
        dob = dd.toString() + "-" + mm.toString() + "-" + yy.toString();
        String cname = txtcontactno.getText();
        String price = txtprice.getText();
        String qty = txtqtyy.getText();
        String total = txttotal.getText();


        if (!salesid.equals("") && !productid.equals("")) {
            try {
                con = connection.connect.makeConnection();
                String Query = "insert into bill_records(salesid,Productid,pname,dob,cname,price,qty,total) values(?,?,?,?,?,?,?,?)";
                ps = con.prepareStatement(Query);
                ps.setString(1, salesid);
                ps.setString(2, productid);

                ps.setString(3, pname);
                ps.setString(4, dob);
                ps.setString(5, cname);
                ps.setString(6, price);
                ps.setString(7, qty);
                ps.setString(8, total);

                int j = ps.executeUpdate();
                if (j > 0) {
                     PreparedStatement pt=con.prepareStatement("update AutoGen set SalesID=SalesID+1");
    pt.executeUpdate();
                    JOptionPane.showMessageDialog(null, "New Bill is Created");
                    clear();
                } else {
                    JOptionPane.showMessageDialog(null, "New Bill Is Not Created");
                }
                ps.close();
                con.close();
                   con1 = connection.connect.makeConnection();
                String sql = "select noofunit from items where Item_Id='" + productid + "'";
                pst1 = con1.prepareStatement(sql);
                rst1 = pst1.executeQuery();
             if (rst1.next()) {
                    String amount = rst1.getString(1);
                    System.out.println("jjjjjjjjjj"+amount);
                    int stk =Integer.parseInt(amount);
   int amt1 = Integer.parseInt(qty);
               int updatestk = stk -amt1;
 System.out.println("jjjjjjjssssssssssjjj"+updatestk);
                    //String stkqty = String.valueOf(updatestk);
                    String updsql = "update items set noofunit=? where Item_Id='" + productid + "'";
                    System.out.println("SQL Query----------:"+updsql);
                    pst1 = con1.prepareStatement(updsql);
                    pst1.setInt(1, updatestk);
                    int k = pst1.executeUpdate();
                }
                 pst1.close();
                con1.close();
                rst1.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Sales Id and Name Cannot Blank Left !!");
            return;
        }
    }//GEN-LAST:event_btnsaveActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        // TODO add your handling code here:

        String salesid = txtenrol_no.getText();
        String productid = (String) txtname.getSelectedItem();
        String pname = jTextField1.getText();
        dd = cmbdd.getSelectedItem();
        mm = cmbmm.getSelectedItem();
        yy = cmbyy.getSelectedItem();
        dob = dd.toString() + "-" + mm.toString() + "-" + yy.toString();
        String cname = txtcontactno.getText();
        String price = txtprice.getText();
        String qty = txtqtyy.getText();
        String total = txttotal.getText();

        if (!salesid.equals("")) {
            try {
                con = connection.connect.makeConnection();
                String Query = "update bill_records set Productid = ?,pname=?,dob=?,cname=?,price=?,qty=?,total=? where salesid ='" + salesid + "'";
                ps = con.prepareStatement(Query);

                ps.setString(1, productid);

                ps.setString(2, pname);
                ps.setString(3, dob);
                ps.setString(4, cname);
                ps.setString(5, price);
                ps.setString(6, qty);
                ps.setString(7, total);
                int j = ps.executeUpdate();
                if (j > 0) {
                    JOptionPane.showMessageDialog(null, "Updated");
                } else {
                    JOptionPane.showMessageDialog(null, "Not Updated !!");
                }
                ps.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Sales ID  Cannot Blank Left !!");
            return;
        }
    }//GEN-LAST:event_btnupdateActionPerformed

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        // TODO add your handling code here:
        cus_no = txtenrol_no.getText();
        if (!cus_no.equals("")) {
            try {
                con = connection.connect.makeConnection();
                st = con.createStatement();
                String query = "select salesid,Productid,pname,dob,cname,price,qty,total from bill_records where salesid ='" + cus_no + "'";
                rs = st.executeQuery(query);
                if (rs.next()) {
                    txtenrol_no.setText(rs.getString(1));
                    txtname.setSelectedItem(rs.getString(2));
                   jTextField1.setText(rs.getString(2));
                    String temp[] = rs.getString(4).split("-");
                    cmbdd.setSelectedItem(temp[0]);
                    cmbmm.setSelectedItem(temp[1]);
                    cmbyy.setSelectedItem(temp[2]);
                    txtcontactno.setText(rs.getString(5));
                    txtprice.setText(rs.getString(6));
                    txtqtyy.setText(rs.getString(7));
    txttotal.setText(rs.getString(8));

                } else {
                    JOptionPane.showMessageDialog(null, "Sales ID Is  Not Found !!");
                    return;
                }

                st.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Sales ID Cannot Blank Left !!");
            return;
        }

    }//GEN-LAST:event_btnsearchActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        // TODO add your handling code here:

        cus_no = txtenrol_no.getText();
        if (!cus_no.equals("")) {
            try {
                con = connection.connect.makeConnection();
                st = con.createStatement();
                String query = "delete from bill_records where salesid ='" + cus_no + "'";
                int res = st.executeUpdate(query);
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "Delete Successfully !!");
                    clear();
                } else {
                    JOptionPane.showMessageDialog(null, "Not Deleted !!");
                    return;
                }

                st.close();
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Sales ID Cannot Blank Left !!");
            return;
        }
    }//GEN-LAST:event_btndeleteActionPerformed

    private void btnclearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnclearActionPerformed
        // TODO add your handling code here:
        clear();
    }//GEN-LAST:event_btnclearActionPerformed
  
    private void txtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameActionPerformed
  
        try
   {
          con = connection.connect.makeConnection();
 Statement st = con.createStatement();
     ResultSet rs=st.executeQuery("select * from Items where Item_Id='"+txtname.getSelectedItem()+"'");
     while(rs.next())
     {
         jTextField1.setText(rs.getString(2));
        txtprice.setText(rs.getString(6));
        
        


     }
     


   }
   catch(Exception e)
   {
       System.out.println();
   }
        

    }//GEN-LAST:event_txtnameActionPerformed

    private float getTotal()
    {
        price=Float.parseFloat(txtprice.getText());
        discount=100-Float.parseFloat(txtDiscount.getText());
        total=price*(discount/100);
        return total;
    }

    private void txttotalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txttotalMouseClicked

        String price = txtprice.getText();
        String qty = txtqtyy.getText();
        int stk =Integer.parseInt(price);
   int amt1 = Integer.parseInt(qty);
               int updatestk = stk *amt1;
               System.out.println("no total"+updatestk);
               txttotal.setText(""+updatestk);
         

    }//GEN-LAST:event_txttotalMouseClicked

    private void txtenrol_noMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtenrol_noMouseClicked
      try
   {
       con = connection.connect.makeConnection();
 Statement st = con.createStatement();

       ResultSet ra=st.executeQuery("select SalesID from AutoGen");
       while(ra.next())
       {
           txtenrol_no.setText(ra.getString(1));
       }
   }
   catch(Exception e)
   {
       System.out.println(e+"");
   }        // TODO add your handling code here:
    }//GEN-LAST:event_txtenrol_noMouseClicked

    private void txtcontactnoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtcontactnoMouseClicked
        // TODO add your handling code here:
}//GEN-LAST:event_txtcontactnoMouseClicked

    private void txtenrol_noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtenrol_noActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtenrol_noActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

           Sales_Person obj=new Sales_Person();
       obj.show();// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cmbyyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbyyActionPerformed
        // TODO add your handling code here:
}//GEN-LAST:event_cmbyyActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
           NewCustomer obj=new NewCustomer();
       obj.show();// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnsave1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsave1ActionPerformed
        // TODO add your handling code here:
        if(txtqtyy.getText().equals(""))
        {
            txttotal.setText(String.valueOf(getTotal()));
        }
        else
        {
            
            Float quantity=Float.parseFloat(txtqtyy.getText());
            txttotal.setText(String.valueOf(getTotal()*quantity));
        }
       
        
    }//GEN-LAST:event_btnsave1ActionPerformed

    private void btnsave2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsave2ActionPerformed
        // TODO add your handling code here:
   connect frm=new connect();
   Statement st=null;
   ResultSet rs=null;
             try
        {
            st=frm.makeConnection().createStatement();
            rs=st.executeQuery("select * from items where code='"+txtCode.getText()+"'");
            if(rs.next())
            {
                jTextField1.setText(rs.getString("itemname"));
                txtprice.setText(rs.getString("itemprice"));
                
                
            }
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_btnsave2ActionPerformed

    private void txtCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodeActionPerformed

    private void txttotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttotalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new CreateBill().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnclear;
    private javax.swing.JButton btndelete;
    private javax.swing.JButton btnsave;
    private javax.swing.JButton btnsave1;
    private javax.swing.JButton btnsave2;
    private javax.swing.JButton btnsearch;
    private javax.swing.JButton btnupdate;
    private javax.swing.JComboBox cmbdd;
    private javax.swing.JComboBox cmbmm;
    private javax.swing.JComboBox cmbyy;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txtCode;
    private javax.swing.JTextField txtDiscount;
    private javax.swing.JTextField txtDiscount1;
    private javax.swing.JTextField txtcontactno;
    private javax.swing.JTextField txtenrol_no;
    private javax.swing.JComboBox txtname;
    private javax.swing.JTextField txtprice;
    private javax.swing.JLabel txtqty;
    private javax.swing.JLabel txtqty1;
    private javax.swing.JLabel txtqty3;
    private javax.swing.JTextField txtqtyy;
    private javax.swing.JTextField txttotal;
    // End of variables declaration//GEN-END:variables

    public void clear() {

        txtenrol_no.setText("");
        txtname.setSelectedIndex(0);
                jTextField1.setText("");
      
        cmbdd.setSelectedIndex(0);
        cmbmm.setSelectedIndex(0);
        cmbyy.setSelectedIndex(0);
       txtcontactno.setText("");
        txtprice.setText("");
        txtqtyy.setText("");
        txttotal.setText("");
        txtCode.setText("");
        txtDiscount.setText("");


    }
}
